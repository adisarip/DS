To run the code

python3 2.py {Path to code} {Module name}

Module name example = 20171191_2 for 20171191_2.erl
import sys
import os

code_file = sys.argv[1]
module_name = sys.argv[2]

input_folder = "Test_Cases/Inputs/"
output_folder = "Outputs/"
result_folder = "Test_Cases/Results/"

os.system("erlc " + code_file)
score_file = open("Result.txt", "w+")
score = 0
var = 0

for file in os.listdir(input_folder):
    var += 1
    input_file = os.path.join(input_folder + "input_" + str(var))
    output_file = output_folder + "output_" + str(var)
    result_file = result_folder + "result_" + str(var)
    os.system("touch " + output_file)
    try:
        os.system("erl -noshell -s " + module_name + " main " + input_file + " " + output_file + " -s init stop")

        f1 = open(output_file, 'r')
        lines1 = f1.readlines()

        f2 = open(result_file, 'r')
        lines2 = f2.readlines()

        arr1 = []
        arr2 = []
        for line in lines1:
            line = line.strip()
            if line == "":
                continue
            arr1.append(line)
        for line in lines2:
            line = line.strip()
            if line == "":
                continue
            arr2.append(line)
        score_string = "Test Case : " + str(var) + " -> "
        if arr1 != arr2:
            score_string += "WA\n"
            score_file.write(score_string)
        else:
            score_string += "AC\n"
            score_file.write(score_string)
            score += 1
    except:
        score_file.write("Test Case : " + str(var) + " -> SegFault\n")

score_file.write("\nScore = " + str(score) + "\n")
score_file.close()
    


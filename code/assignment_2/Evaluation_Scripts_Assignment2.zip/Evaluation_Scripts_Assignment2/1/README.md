To run the code

python3 1.py {Path to code} {Module name}

Module name example = 20171191_1 for 20171191_1.erl
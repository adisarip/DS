import sys
import os

code_file = sys.argv[1]
module_name = sys.argv[2]

input_folder = "Test_Cases/Inputs/"
output_folder = "Test_Cases/Outputs/"

os.system("erlc " + code_file)
result_file = open("Result.txt", "w+")
score = 0
var = 0

for file in os.listdir(input_folder):
	var += 1
	input_file = os.path.join(input_folder + file)
	output_file = output_folder + "output_" + str(var)
	os.system("touch " + output_file)
	try:
		os.system("erl -noshell -s " + module_name + " main " + input_file + " " + output_file + " -s init stop")

		f = open(input_file, 'r')
		line = f.read().strip()
		f.close()

		p = int(line.split(' ')[0])
		m = int(line.split(' ')[1])

		f = open(output_file, 'r')
		lines = f.readlines()

		flag = True
		count = 0
		diff = 0

		for line in lines:
			line = line.strip()
			if line == "":
				continue
			count += 1
			token = int(line.split(' ')[4])
			if token != m:
				flag = False
				break
			to_v = int(line.split(' ')[1])
			from_v = int(line.split(' ')[7].split('.')[0])
			if diff != 1 and diff != -1:
				diff = to_v - from_v
			nxt = (from_v + diff + p) % p
			if nxt != to_v:
				flag = False
				break
		result_string = "Test Case : " + str(var) + " -> "
		if flag == False or count != p:
			result_string += "WA\n"
			result_file.write(result_string)
		else:
			result_string += "AC\n"
			result_file.write(result_string)
			score += 1
	except:
		result_file.write("Test Case : " + str(var) + " -> SegFault\n")

result_file.write("\nScore = " + str(score) + "\n")
result_file.close()
	

